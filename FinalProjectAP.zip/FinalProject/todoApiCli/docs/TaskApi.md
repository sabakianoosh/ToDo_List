# todoApiCli.Api.TaskApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TaskGet**](TaskApi.md#taskget) | **GET** /task | 
[**TaskIdDelete**](TaskApi.md#taskiddelete) | **DELETE** /task/{id} | 
[**TaskIdGet**](TaskApi.md#taskidget) | **GET** /task/{id} | 
[**TaskNameGet**](TaskApi.md#tasknameget) | **GET** /task/{name} | 
[**TaskPost**](TaskApi.md#taskpost) | **POST** /task | 


<a name="taskget"></a>
# **TaskGet**
> List&lt;Task&gt; TaskGet ()



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using todoApiCli.Api;
using todoApiCli.Client;
using todoApiCli.Model;

namespace Example
{
    public class TaskGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new TaskApi(config);

            try
            {
                List<Task> result = apiInstance.TaskGet();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TaskApi.TaskGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Task&gt;**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="taskiddelete"></a>
# **TaskIdDelete**
> void TaskIdDelete (int id)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using todoApiCli.Api;
using todoApiCli.Client;
using todoApiCli.Model;

namespace Example
{
    public class TaskIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new TaskApi(config);
            var id = 56;  // int | 

            try
            {
                apiInstance.TaskIdDelete(id);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TaskApi.TaskIdDelete: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="taskidget"></a>
# **TaskIdGet**
> Task TaskIdGet (int id)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using todoApiCli.Api;
using todoApiCli.Client;
using todoApiCli.Model;

namespace Example
{
    public class TaskIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new TaskApi(config);
            var id = 56;  // int | 

            try
            {
                Task result = apiInstance.TaskIdGet(id);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TaskApi.TaskIdGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

[**Task**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="tasknameget"></a>
# **TaskNameGet**
> Task TaskNameGet (string name)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using todoApiCli.Api;
using todoApiCli.Client;
using todoApiCli.Model;

namespace Example
{
    public class TaskNameGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new TaskApi(config);
            var name = "name_example";  // string | 

            try
            {
                Task result = apiInstance.TaskNameGet(name);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TaskApi.TaskNameGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **string**|  | 

### Return type

[**Task**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="taskpost"></a>
# **TaskPost**
> void TaskPost (Task task = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using todoApiCli.Api;
using todoApiCli.Client;
using todoApiCli.Model;

namespace Example
{
    public class TaskPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new TaskApi(config);
            var task = new Task(); // Task |  (optional) 

            try
            {
                apiInstance.TaskPost(task);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TaskApi.TaskPost: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **task** | [**Task**](Task.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

