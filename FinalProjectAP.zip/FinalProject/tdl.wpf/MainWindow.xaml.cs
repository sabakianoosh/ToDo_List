﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using todoApiCli.Api; 
using todoApiCli.Client; 
using todoApiCli.Model;
using Microsoft.AspNetCore.SignalR.Client;
using System.Data;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Windows.Navigation;

namespace TodoList
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            hc = new HubConnectionBuilder()
            .WithUrl("http://localhost:5000/datahub")
            .Build();
            hc.On("refresh", () => {var dg = show(); dataGrid.ItemsSource = dg;});
            hc.StartAsync();
            refreshui();

            
        }
        public List<todoApiCli.Model.Task> show()
        {
            Configuration config = new Configuration() {BasePath = "http://localhost:5000"}; 
            TaskApi apiInstance = new TaskApi(config);
            var p = apiInstance.TaskGet();
            return p;
        }

        HubConnection hc;
        public void exit(object sender,RoutedEventArgs args)
        {
            this.Close();
        }

        public void refreshui()
        {
            Configuration config = new Configuration() {BasePath = "http://localhost:5000"}; 
            TaskApi apiInstance = new TaskApi(config);
                hc.SendAsync("data");

            
        }

        public void  add_task(object sender,RoutedEventArgs args)
        {
            Configuration config = new Configuration() {BasePath = "http://localhost:5000"}; 
            TaskApi apiInstance = new TaskApi(config);

            if (string.IsNullOrWhiteSpace(tbnewtask.Text))
            {
                MessageBox.Show("Empty box!");
            }

            else
            {
                var newtask = new todoApiCli.Model.Task((apiInstance.TaskGet().Count())+1,tbnewtask.Text);
                apiInstance.TaskPost(newtask);
                hc.SendAsync("data");
                tbnewtask.Text = string.Empty;
            }
        }

        public void remove_task(object sender,RoutedEventArgs args)
        {
            Configuration config = new Configuration() {BasePath = "http://localhost:5000"}; 
            TaskApi apiInstance = new TaskApi(config);
            if (string.IsNullOrWhiteSpace(tbtask2delete.Text))
            {
                MessageBox.Show("There is nothing to remove");
            }
            else
            {
                int id  = int.Parse(tbtask2delete.Text);
                apiInstance.TaskIdDelete(id);
                hc.SendAsync("data");
                tbtask2delete.Text = string.Empty;
            }

        }
    }
}
