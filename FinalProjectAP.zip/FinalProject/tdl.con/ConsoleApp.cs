﻿// // // // context.tasks.Add(new task(1,"reading"));
// // // // Console.WriteLine("done");

using todoApiCli.Api; 
using todoApiCli.Client; 
using todoApiCli.Model;
using Microsoft.AspNetCore.SignalR.Client;


public class ConsoleApp
{
    HubConnection hc;
    TaskApi apiInstance ;
    Configuration config;
    public  void refreshui()
    {
         this.config ??= new Configuration() {BasePath = "http://localhost:5000"}; 
        this.apiInstance ??= new TaskApi(config); 
         foreach(var s in apiInstance.TaskGet()) 
            Console.WriteLine(s);
    }
    public ConsoleApp()
    {
        var apprunning = true;
        this.config ??= new Configuration() {BasePath = "http://localhost:5000"}; 
        this.apiInstance ??= new TaskApi(config); 

         hc = new HubConnectionBuilder()
            .WithUrl("http://localhost:5000/datahub")
            .Build();
            hc.On("refresh", () => refreshui());
            hc.StartAsync();

    while (apprunning)
    {
        Console.WriteLine(" Show your list, Add or Remove item."); 
        var input = Console.ReadLine();

        switch(input)
            {
                case string a  when a.StartsWith("add"):
                string newtaskname = a.Substring(4,(input.Length)-4).ToString();
                var newtask = new todoApiCli.Model.Task((apiInstance.TaskGet().Count())+1,newtaskname);
                apiInstance.TaskPost(newtask);
                hc.SendAsync("data");
                break;

                case string b when b.StartsWith("remove"):
                int id =int.Parse(b.Substring(7,(input.Length)-7));
                apiInstance.TaskIdDelete(id);
                hc.SendAsync("data");
                break;

                case "show":
                foreach(var s in apiInstance.TaskGet()) 
                Console.WriteLine(s);
                break;

                case "exit":
                apprunning = false;
                break;

                default:
                {break;}

            }

    }
    }
    public static void Main()
    {
        var c = new ConsoleApp();
    }

}