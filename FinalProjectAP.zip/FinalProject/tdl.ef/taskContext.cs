using Microsoft.EntityFrameworkCore;


    public class taskContext : DbContext
    {
        public taskContext(DbContextOptions<taskContext> options)
        : base(options)
        {
        }
        public DbSet<task> tasks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        { 
            optionsBuilder.UseSqlite(@"Data Source=task.db");
        }
    }