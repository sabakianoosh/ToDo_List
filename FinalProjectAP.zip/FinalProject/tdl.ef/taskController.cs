using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("[controller]")]
public class taskController : ControllerBase
{
    taskService _service;
    
    public taskController(taskService service)
    {
        _service = service;
    }

    [HttpGet]
    public IEnumerable<task> GetAll()
    {
        return _service.GetAll();
    }

    [HttpGet("{name}")]
    public ActionResult<task> GetByName(string name)
    {
        var task = _service.GettaskByName(name);

        if(task is not null)
        {
            return task;
        }
        else
        {
            return NotFound();
        }
    }

     [HttpGet("{id}")]
    public ActionResult<task> GetById(int id)
    {
        var t = _service.GettaskById(id);

        if(t is not null)
        {
            return t;
        }
        else
        {
            return NotFound();
        }
    }



    [HttpPost]
     public IActionResult Create(task newtask)
    {
        var task = _service.Create(newtask);
        return CreatedAtAction(nameof(GetById), new { id = task!.taskId }, task);
    }

   

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var tk = _service.GettaskById(id);

        if(tk is not null)
        {
            _service.DeletetaskById(id);
            return Ok();
        }
        else
        {
            return NotFound();
        }
    }
}