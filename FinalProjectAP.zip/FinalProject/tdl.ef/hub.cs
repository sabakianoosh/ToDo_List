using Microsoft.AspNetCore.SignalR;
 public class datahub : Hub

 {
    public async Task  data()
    {
        await Clients.All.SendAsync("refresh");
    }
 }