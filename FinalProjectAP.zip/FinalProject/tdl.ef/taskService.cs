using Microsoft.EntityFrameworkCore;

public class taskService
{
    private readonly taskContext _context;
    public taskService(taskContext context)
    {
        _context = context;
    }

    public IEnumerable<task> GetAll() => _context.tasks.AsNoTracking().ToList();

    public task GettaskByName(string name) => _context.tasks
        .AsNoTracking()
        .SingleOrDefault(p => p.taskName == name);

     public task GettaskById(int id) => _context.tasks
        .AsNoTracking()
        .SingleOrDefault(p => p.taskId == id);


    public task Create(task newtask)
    {
        _context.tasks.Add(newtask);
        _context.SaveChanges();
        return newtask;
    }
    
     public void DeletetaskById(int id)
    {
        var task2delete = _context.tasks.Find(id);
        if (task2delete is not null)
        {
            _context.tasks.Remove(task2delete);
            _context.SaveChanges();
        }
    }


}