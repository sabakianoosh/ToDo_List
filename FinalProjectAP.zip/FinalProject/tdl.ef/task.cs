using System;
using System.Collections.Generic;

public class task
{
   public task(){}
   public task (int taskId , string taskName)
   {
      this.taskName = taskName;
      this.taskId = taskId;
   }
    public int taskId{get;set;}

    public string taskName {get;set;}
    
}